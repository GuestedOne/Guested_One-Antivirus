## EN



# Copyright and credits

## Project ownership

Copyright (c) 2025–2026 Первый_Гостевой (Guested_One).

The Guested_One / GUESTED_ONE project name, G1 product names, original application code authored by the project creator, original interface copy, artwork created for the project, and project documentation are covered by the G1-EULA v1.0 in `LICENSE.md`, except where a component is explicitly identified as third-party material.

## Project credits

- Первый_Гостевой (Guested_One) — project creator, concept, direction, and maintainer.
- flane.channel — friend of the project creator; special thanks for support of 50 RUB via DonationAlerts and encouragement of the project's development. This acknowledgement does not imply code authorship or ownership.

## Third-party software

Guested_One uses Python's standard library and Tkinter (distributed with or alongside Python, depending on the platform). `psutil` is an optional third-party dependency for richer process and network information; it is not required for basic scanning. Consult the license and notice files of each third-party package installed in your environment. Third-party components remain subject to their own licenses and copyrights.

## No endorsement

Names of operating systems, Python, Tkinter, psutil, DonationAlerts, and AI services are used only to identify compatibility, dependencies, or acknowledgements. Their respective owners do not endorse or certify Guested_One Antivirus.



## RU



# Авторское право и благодарности

## Принадлежность проекта

Авторское право (c) 2025–2026 Первый_Гостевой (Guested_One).

Название проекта Guested_One / GUESTED_ONE, наименования продуктов серии G1, исходный код приложения, написанный автором проекта, оригинальные тексты интерфейса, графические материалы, созданные для проекта, а также документация к проекту подпадают под действие лицензионного соглашения G1-EULA v1.0 (см. файл `LICENSE.md`), за исключением тех компонентов, которые прямо обозначены как материалы сторонних разработчиков.

## Благодарности

- Первый_Гостевой (Guested_One) — создатель проекта, автор концепции, руководитель и сопровождающий проекта.
- flane.channel — друг создателя проекта; особая благодарность за поддержку в размере 50 руб. через сервис DonationAlerts и за содействие развитию проекта. Данное упоминание не означает, что этот пользователь является автором кода или владельцем проекта.

## Стороннее программное обеспечение

В проекте Guested_One используются стандартная библиотека Python и графический интерфейс Tkinter (распространяются вместе с Python или отдельно, в зависимости от платформы). Библиотека `psutil` является опциональной сторонней зависимостью, позволяющей получать более подробную информацию о процессах и сети; для базового сканирования она не требуется. Пожалуйста, ознакомьтесь с лицензиями и сопроводительными файлами каждого стороннего пакета, установленного в вашей системе. На сторонние компоненты распространяются их собственные лицензии и авторские права.

## Отсутствие официальной поддержки

Названия операционных систем, Python, Tkinter, psutil, DonationAlerts и сервисов на базе G1 используются исключительно для указания совместимости, зависимостей или в целях выражения признательности. Владельцы этих продуктов и сервисов не оказывают поддержку проекту Guested_One Antivirus и не предоставляют ему каких-либо официальных сертификатов.