@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Guested_One Setup 1.0.0

cd /d "%~dp0"
set "SCRIPT=%~dp0GuestedOne_Setup_1.0.0.py"

echo ==========================================
echo        Guested_One Setup 1.0.0
echo ==========================================
echo.

if not exist "%SCRIPT%" (
    echo ERROR: GuestedOne_Setup_1.0.0.py was not found.
    echo Put this BAT file in the same folder as the PY file.
    echo.
    echo Expected file:
    echo "%SCRIPT%"
    goto :failed
)

set "PYTHON_CMD="
where py.exe >nul 2>nul
if not errorlevel 1 set "PYTHON_CMD=py.exe"

if not defined PYTHON_CMD (
    where python.exe >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=python.exe"
)

if not defined PYTHON_CMD (
    echo ERROR: Python was not found in PATH.
    echo Install Python 3 and enable "Add Python to PATH".
    goto :failed
)

echo Starting installer with %PYTHON_CMD% ...
echo.

if "%PYTHON_CMD%"=="py.exe" (
    py.exe -3 "%SCRIPT%"
) else (
    python.exe "%SCRIPT%"
)

set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
    echo Installer exited with error code %RC%.
    goto :failed
)

echo Installer finished.
echo.
pause
exit /b 0

:failed
echo.
echo Launch failed. Read the error above.
echo.
pause
exit /b 1
