# Building Guested_One Setup 1.0.0 as a Windows EXE

The provided Setup is a Python GUI installer. Its `.bat` launchers are shortcuts created for the installed application; they are not the Setup itself.

To create a real Windows installer executable:

1. On a Windows 10/11 machine, install Python 3.13.4 or newer.
2. Keep `GuestedOne_Setup_1.0.0.py` and `Build_Setup_EXE_Windows.bat` in the same folder.
3. Double-click `Build_Setup_EXE_Windows.bat`.
4. The generated executable will be `dist\GuestedOne_Setup_1.0.0.exe`.

PyInstaller must be run on Windows to produce a native Windows executable. A Linux-built executable is not a Windows `.exe`.

**Important limitation:** this packages the Setup GUI as an EXE. The current installer still extracts the antivirus Python source and launches it with the installed Python interpreter. It does not yet bundle the antivirus runtime into a standalone `GuestedOneAntivirus.exe`. Python and Tkinter remain required for the installed antivirus in this build.
