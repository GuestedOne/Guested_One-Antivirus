# EN



# Guested_One Antivirus — 1.0.0

**G1 Security Platform · Первый стабильный публичный релиз**

Guested_One Antivirus is a Python desktop security utility built around local file scanning, heuristic checks, quarantine management, process inspection, local configuration, and optional plug-ins. The application is authored by **Первый_Гостевой (Guested_One)**.

> **Important:** G1 is an experimental, heuristic security utility. It is not a certified antivirus product, does not provide kernel-level or guaranteed real-time protection, and cannot guarantee detection of every threat. Keep your operating system security tools enabled and maintain backups.

## Features

- Tkinter desktop interface with a separate, windowed startup splash screen.
- File and directory scanning with fast, automatic, and deep modes.
- Heuristic detection for selected suspicious file patterns and the EICAR test signature.
- Quarantine manager, scan reports, activity log, and local Security Center.
- Process and network-endpoint inspection (extended details use optional `psutil`).
- Local plug-in catalog and a developer plug-in interface.
- Local assistant **ИИ_Гостевой** (rule-based knowledge assistant; not an LLM).
- Local-only profiles and leaderboard; no online leaderboard service is included.
- Backup and recovery for supported configuration data.
- Standalone Python Setup generator and uninstaller.

### Plug-in security warning

Plug-ins are Python modules. A Python plug-in loaded by G1 executes with the permissions of the Guested_One process. The current plug-in interface is **not a security sandbox**. Only install plug-ins whose source you trust. Do not assume that a catalogue entry, checksum, or plug-in name proves the code is safe.

## Requirements

- Python **3.14.3 or newer** is recommended.
- Tkinter for the graphical interface and graphical Setup wizard.
- `psutil` is optional and provides richer process, memory, CPU, and network information.

Install the optional module with:

```bash
python -m pip install psutil
```

### Tkinter notes

- **Windows:** use a Python distribution that includes Tcl/Tk.
- **macOS:** use a Python build with Tk support. Some Python distributions package Tk separately.
- **Linux / Ubuntu:** install the Tkinter package for the Python version in use. On Ubuntu's system Python, the package is commonly available as `python3-tk`.

The application can still run command-line scanning without opening its desktop GUI. The graphical Setup wizard falls back to a console installer when Tkinter is unavailable.

## Run from source

```bash
# Windows (PowerShell)
py Guested_One_v1.0.0.py --version
py Guested_One_v1.0.0.py --scan "$env:USERPROFILE\Documents" --mode auto --report report.txt

# macOS / Linux / Ubuntu
python3 Guested_One_v1.0.0.py --version
python3 Guested_One_v1.0.0.py --scan "$HOME/Documents" --mode auto --report report.txt
```

Start the graphical application:

```bash
# Windows
py Guested_One_v1.0.0.py

# macOS / Linux / Ubuntu
python3 Guested_One_v1.0.0.py
```

### Useful command-line options

| Option | Purpose |
|---|---|
| `--version` | Print the application version and exit. |
| `--scan PATH` | Scan a file or directory. |
| `--mode fast\|auto\|deep` | Select scan depth. |
| `--report FILE` | Save a scan report. |
| `--list-plugins` | List locally loaded plug-ins. |
| `--make-setup [PATH]` | Build a self-contained Python Setup script. |
| `--test-taskmgr-detection` | Run a harmless in-memory heuristic self-test; does not modify Windows policies or registry. |
| `--eicar` | Create the standard harmless EICAR test file for scanner validation. |

Windows-specific administrative features (for example, Task Manager policy repair, Registry integration, and certain account/service controls) are not available on macOS or Linux. Availability of other system details depends on the OS, permissions, and optional tools installed.

## Build the standalone Setup script

From the project directory:

```bash
# Windows
py Guested_One_v1.0.0.py --make-setup GuestedOne_Setup_1.0.0.py

# macOS / Linux / Ubuntu
python3 Guested_One_v1.0.0.py --make-setup GuestedOne_Setup_1.0.0.py
```

Run the generated installer:

```bash
# Windows
py GuestedOne_Setup_1.0.0.py

# macOS / Linux / Ubuntu
python3 GuestedOne_Setup_1.0.0.py
```

The Setup script embeds the G1 application source, extracts it to a per-user installation directory, creates platform-appropriate launch entries where supported, and writes an uninstaller. It does not bundle the Python runtime or Tkinter; the target computer needs a compatible Python installation. The installer itself uses only Python's standard library plus Tkinter for its GUI.

## Platform support status

| Platform | CLI scanning | Tkinter GUI | Installer integration |
|---|---|---|---|
| Windows 10/11 | Supported | Supported with Python + Tk | `.bat` launchers, Start Menu entries, optional Startup entry, per-user install directory |
| macOS | Supported | Supported with Python + Tk | `.command` launchers and optional per-user LaunchAgent |
| Linux | Supported | Supported with Python + Tk | `.desktop` application entries and optional autostart |
| Ubuntu | Supported | Supported with Python + Tk package | Linux `.desktop` integration |

Release verification limitation: the source, CLI, and installer bundle are syntax-checked and exercised in a Linux test environment. Windows and macOS have platform-specific code paths, but a native Windows/macOS runtime test has not been performed in this release environment. Treat those platforms as supported-by-design pending native-device validation before making broad compatibility claims.

## Run the release smoke tests

After placing the application, Setup script, and `test_release.py` in the same directory:

```bash
python test_release.py
```

The tests cover the local leaderboard ordering and corrupt-profile migration, the harmless in-memory Task Manager detector test, embedded Setup payload equality, generated uninstaller syntax, and platform-specific launcher-file generation. The Windows/macOS launchers are tested as generated files in the Linux test environment; these tests are not substitutes for installing and running the release on native Windows and macOS machines.

## Data and privacy

Configuration, local profiles, logs, reports, and quarantine data are stored under:

Users/[YOUR USER NAME]/.guested_one/

The local leaderboard is stored on the current device. It is not a public leaderboard and is not synchronized with GitHub or any server. Review logs and reports before sharing them; they may contain local file paths and system details.

## Repository files

- `GuestedOne_Setup_1.0.0.py` — self-contained installer generated from the source.
- `README.md` — project overview and setup instructions.
- `LICENSE.md` — G1-EULA v1.0.
- `COPYRIGHT.md` — attribution and third-party notices.
- `SHA256SUMS.txt` — For Linux/Ubuntu and MacOS users.

## Credits

Project concept, direction, and authorship: **Первый_Гостевой (Guested_One)**.

Special Thanks to: flane.channel - for: supporting the project with 50 RUB through DonationAlerts and encouraging its development.
If you have any reports of bugs or something is NOT working - create a video, tag @Первый_Гостевой (Or @Guested_One) and sent me the link for the video under my latest Entries. Thanks for using and reading our README.md!
-Wishes and Copyrights, Guested_One / Первый_Гостевой.



# RU



Guested_One Antivirus — 1.0.0

Платформа безопасности G1 · Первый стабильный публичный релиз
Guested_One Antivirus — это настольная утилита безопасности на языке Python, построенная вокруг локального сканирования файлов, эвристических проверок, управления карантином, инспекции процессов, локальной настройки и опциональных плагинов. Автор приложения — Первый_Гостевой (Guested_One).
Важно: G1 — это экспериментальная эвристическая утилита безопасности. Она не является сертифицированным антивирусным продуктом, не обеспечивает защиту на уровне ядра или гарантированную защиту в реальном времени и не может гарантировать обнаружение всех угроз. Держите встроенные средства безопасности операционной системы включёнными и регулярно создавайте резервные копии.

Возможности

• Настольный интерфейс на базе Tkinter с отдельным оконным экраном загрузки (splash screen).
• Сканирование файлов и каталогов в быстром, автоматическом и глубоком режимах.
• Эвристическое обнаружение ряда подозрительных шаблонов файлов и тестовой сигнатуры EICAR.
• Менеджер карантина, отчёты о сканировании, журнал активности и локальный Центр безопасности.
• Инспекция процессов и сетевых подключений (расширенные сведения доступны при установке опционального модуля psutil).
• Локальный каталог плагинов и интерфейс разработки плагинов.
• Локальный ассистент ИИ_Гостевой (база знаний на основе правил; не является большой языковой моделью / LLM).
• Исключительно локальные профили и таблица лидеров; онлайн-сервис таблицы лидеров не предусмотрен.
• Резервное копирование и восстановление поддерживаемых данных конфигурации.
• Автономный генератор установщика и деинсталлятора на Python.

Предупреждение о безопасности плагинов

Плагины представляют собой модули Python. Плагин Python, загруженный в G1, выполняется с правами процесса Guested_One. Текущий интерфейс плагинов не является изолированной песочницей (sandbox). Устанавливайте только те плагины, источнику которых вы доверяете. Не считайте наличие записи в каталоге, контрольной суммы или названия плагина доказательством безопасности его кода.

Системные требования

• Рекомендуется Python 3.14.3 или новее.
• Tkinter для графического интерфейса и графического мастера установки.
• Модуль psutil является опциональным и предоставляет более подробную информацию о процессах, памяти, ЦП и сети.
Установить опциональный модуль можно командой:
bash
python -m pip install psutil
Используйте код с осторожностью.

Примечания по Tkinter

• Windows: используйте дистрибутив Python, включающий Tcl/Tk.
• macOS: используйте сборку Python с поддержкой Tk. Некоторые дистрибутивы Python поставляют Tk отдельно.
• Linux / Ubuntu: установите пакет Tkinter для используемой версии Python. Для системного Python в Ubuntu этот пакет обычно называется python3-tk.
Приложение также может выполнять сканирование из командной строки без запуска графического интерфейса. Графический мастер установки переключается на консольный установщик, если Tkinter недоступен.

Запуск из исходного кода

# Windows (PowerShell)
py Guested_One_v1.0.0.py --version
py Guested_One_v1.0.0.py --scan "$env:USERPROFILE\Documents" --mode auto --report report.txt

# macOS / Linux / Ubuntu
python3 Guested_One_v1.0.0.py --version
python3 Guested_One_v1.0.0.py --scan "$HOME/Documents" --mode auto --report report.txt

Запуск графического приложения:

# Windows
py Guested_One_v1.0.0.py

# macOS / Linux / Ubuntu
python3 Guested_One_v1.0.0.py


Полезные параметры командной строки


Параметр	Назначение
--version	Вывести версию приложения и завершить работу.
--scan PATH	Просканировать файл или каталог.
--mode fast|auto|deep	Выбрать глубину сканирования.
--report FILE	Сохранить отчёт о сканировании.
--list-plugins	Вывести список локально загруженных плагинов.
--make-setup [PATH]	Собрать автономный Python-скрипт установки.
--test-taskmgr-detection	Запустить безвредное самотестирование эвристики в памяти; не изменяет политики или реестр Windows.
--eicar	Создать стандартный безвредный тестовый файл EICAR для проверки сканера.

Административные функции, специфичные для Windows (например, восстановление политик Диспетчера задач, интеграция с реестром и некоторые элементы управления учётными записями и службами), недоступны в macOS и Linux. Доступность остальных системных сведений зависит от ОС, прав доступа и установленных дополнительных утилит.

Сборка автономного скрипта установки

Из каталога проекта выполните:

# Windows
py Guested_One_v1.0.0.py --make-setup GuestedOne_Setup_1.0.0.py

# macOS / Linux / Ubuntu
python3 Guested_One_v1.0.0.py --make-setup GuestedOne_Setup_1.0.0.py

Запуск сгенерированного установщика:

# Windows
py GuestedOne_Setup_1.0.0.py

# macOS / Linux / Ubuntu
python3 GuestedOne_Setup_1.0.0.py

Используйте код с осторожностью.
Скрипт установки встраивает исходный код приложения G1, распаковывает его в пользовательский каталог установки, создаёт соответствующие платформе ярлыки запуска (где поддерживается) и формирует деинсталлятор. Он не включает в себя среду выполнения Python или Tkinter; на целевом компьютере должна быть установлена совместимая версия Python. Сам установщик использует только стандартную библиотеку Python и Tkinter для графического интерфейса.

Статус поддержки платформ


Платформа	Сканирование через CLI	Графический интерфейс Tkinter	Интеграция установщика
Windows 10/11	Поддерживается	Поддерживается при наличии Python + Tk	Ярлыки .bat, пункты в меню «Пуск», опциональное добавление в автозагрузку, пользовательский каталог установки
macOS	Поддерживается	Поддерживается при наличии Python + Tk	Ярлыки .command и опциональный пользовательский LaunchAgent
Linux	Поддерживается	Поддерживается при наличии Python + Tk	Ярлыки приложений .desktop и опциональный автозапуск
Ubuntu	Поддерживается	Поддерживается при наличии Python + пакета Tk	Интеграция через .desktop для Linux

Ограничение проверки релиза: исходный код, интерфейс командной строки и пакет установщика прошли проверку синтаксиса и тестирование в тестовой среде Linux. Для Windows и macOS предусмотрены специфичные для этих платформ ветки кода, однако нативное тестирование во время выполнения на Windows и macOS в рамках данного релиза не проводилось. До проведения проверки на реальных устройствах считайте эти платформы «поддерживаемыми на уровне архитектуры» (supported-by-design), прежде чем делать широкие заявления о совместимости.

Запуск дымовых тестов (smoke tests) релиза

Поместив приложение, скрипт установки и test_release.py в один каталог, выполните:

python test_release.py

Тесты проверяют сортировку локальной таблицы лидеров и миграцию повреждённых профилей, безвредный тест детектора Диспетчера задач в памяти, идентичность встроенных данных установщика, синтаксис сгенерированного деинсталлятора и создание файлов запуска для конкретных платформ. Ярлыки запуска для Windows и macOS тестируются как сгенерированные файлы в среде Linux; эти тесты не заменяют установку и запуск релиза на нативных машинах под управлением Windows и macOS.

Данные и конфиденциальность

Конфигурация, локальные профили, журналы, отчёты и данные карантина хранятся по пути:
Users/[ВАШЕ ИМЯ ПОЛЬЗОВАТЕЛЯ]/.guested_one/
Локальная таблица лидеров хранится на текущем устройстве. Она не является публичной и не синхронизируется с GitHub или какими-либо серверами. Проверяйте журналы и отчёты перед их отправкой третьим лицам: они могут содержать пути к локальным файлам и сведения о системе.

Файлы репозитория

• GuestedOne_Setup_1.0.0.py — автономный установщик, сгенерированный из исходного кода.
• README.md — обзор проекта и инструкции по установке.
• LICENSE.md — лицензионное соглашение G1-EULA v1.0.
• COPYRIGHT.md — указание авторства и уведомления о сторонних компонентах.
• SHA256SUMS.txt — контрольные суммы для пользователей Linux/Ubuntu и macOS.

Благодарности

Концепция проекта, руководство и авторство: Первый_Гостевой (Guested_One).

Особая благодарность: flane.channel — за поддержку проекта на сумму 50 рублей через DonationAlerts и мотивацию к его дальнейшему развитию.

Если вы обнаружили ошибки или что-то работает не так — запишите видео, отметьте меня (@Первый_Гостевой или @Guested_One) и пришлите ссылку на это видео в комментариях к моей последней публикации. Спасибо, что пользуетесь нашим продуктом и читаете файл README.md!
— С наилучшими пожеланиями, Guested_One / Первый_Гостевой.